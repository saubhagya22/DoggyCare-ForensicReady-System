import React from 'react';
import Health from './components/Health';

function App(){ 
    return (
        <div style={{padding:20}}>
            <h1>Doggy Care — Frontend</h1>
            <Health />
        </div>
    );
}
export default App;
